<?php
// Database settings - change if your MySQL password is not empty
$DB = ['host'=>'localhost','name'=>'hospital_db','user'=>'root','pass'=>''];
session_start();
try {
  $pdo = new PDO("mysql:host={$DB['host']};dbname={$DB['name']};charset=utf8mb4", $DB['user'], $DB['pass'],
    [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
} catch (PDOException $e) {
  die('Database connection failed. Start MySQL, import hospital_db.sql and check config.php');
}
function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function need_login(){ if (empty($_SESSION['user'])) { header('Location: login.php'); exit; } }
function csrf_field(){ if (empty($_SESSION['t'])) $_SESSION['t']=bin2hex(random_bytes(16));
  return '<input type="hidden" name="t" value="'.$_SESSION['t'].'">'; }
function check_csrf(){ if ($_SERVER['REQUEST_METHOD']==='POST' && !hash_equals($_SESSION['t']??'', $_POST['t']??'')) die('Invalid request'); }
function flash($m=null){ if($m!==null){ $_SESSION['f']=$m; return; } $x=$_SESSION['f']??''; unset($_SESSION['f']); return $x; }
