<?php
require 'config.php'; need_login();
$s=$pdo->prepare('SELECT b.*,p.name,p.phone,p.age,p.gender FROM bills b JOIN patients p ON p.patient_id=b.patient_id WHERE b.bill_id=?');
$s->execute([(int)($_GET['id']??0)]); $b=$s->fetch(); if(!$b) die('Bill not found');
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Invoice #<?= $b['bill_id'] ?></title>
<style>body{font-family:Arial,sans-serif;max-width:600px;margin:30px auto;color:#222}table{width:100%;border-collapse:collapse;margin-top:15px}
td,th{border:1px solid #999;padding:8px;text-align:left}h2,p{text-align:center}@media print{button{display:none}}</style></head><body>
<h2>🏥 Hospital Management System</h2><p>INVOICE / BILL RECEIPT</p>
<p style="text-align:left">Bill No: <b><?= $b['bill_id'] ?></b> &nbsp; Date: <b><?= e($b['bill_date']) ?></b><br>
Patient: <b><?= e($b['name']) ?></b> (<?= $b['age'] ?>, <?= e($b['gender']) ?>) &nbsp; Phone: <?= e($b['phone']) ?></p>
<table><tr><th>Description</th><th>Amount</th></tr><tr><td><?= e($b['description']) ?></td><td>₹<?= number_format($b['amount'],2) ?></td></tr>
<tr><th>Total</th><th>₹<?= number_format($b['amount'],2) ?></th></tr><tr><td>Payment Status</td><td><?= e($b['payment']) ?></td></tr></table>
<p><button onclick="window.print()">Print</button></p></body></html>
