<?php
require 'config.php'; need_login(); check_csrf();
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $a=$_POST['action']??'add';
  if ($a==='delete') { $pdo->prepare('DELETE FROM appointments WHERE appointment_id=?')->execute([(int)$_POST['id']]); flash('Appointment deleted.'); }
  elseif ($a==='status' && in_array($_POST['status'],['Scheduled','Completed','Cancelled'])) {
    $pdo->prepare('UPDATE appointments SET status=? WHERE appointment_id=?')->execute([$_POST['status'],(int)$_POST['id']]); flash('Status updated.');
  } elseif ($a==='add') {
    try {
      $pdo->prepare('INSERT INTO appointments(patient_id,doctor_id,appt_date,appt_time) VALUES(?,?,?,?)')
          ->execute([(int)$_POST['patient_id'],(int)$_POST['doctor_id'],$_POST['appt_date'],$_POST['appt_time']]);
      flash('Appointment booked.');
    } catch (PDOException $ex) { flash('Error: this doctor is already booked at that date and time, or details are invalid.'); }
  }
  header('Location: appointments.php'); exit;
}
$title='Appointments';
$pats=$pdo->query('SELECT patient_id,name FROM patients ORDER BY name')->fetchAll();
$docs=$pdo->query('SELECT doctor_id,name,specialization FROM doctors ORDER BY name')->fetchAll();
$rows=$pdo->query('SELECT a.*,p.name pname,d.name dname,d.specialization FROM appointments a
 JOIN patients p ON p.patient_id=a.patient_id JOIN doctors d ON d.doctor_id=a.doctor_id ORDER BY a.appt_date DESC,a.appt_time DESC')->fetchAll();
require 'header.php';
?>
<div class="card"><h3>Book Appointment</h3>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="add">
<div><label>Patient</label><select name="patient_id" required><?php foreach($pats as $p) echo '<option value="'.$p['patient_id'].'">'.e($p['name']).'</option>'; ?></select></div>
<div><label>Doctor</label><select name="doctor_id" required><?php foreach($docs as $d) echo '<option value="'.$d['doctor_id'].'">'.e($d['name'].' ('.$d['specialization'].')').'</option>'; ?></select></div>
<div><label>Date</label><input type="date" name="appt_date" required min="<?= date('Y-m-d') ?>"></div>
<div><label>Time</label><input type="time" name="appt_time" required></div>
<button class="btn">Book</button></form></div>
<div class="card"><h3>All Appointments (<?= count($rows) ?>)</h3><div class="wrap"><table>
<tr><th>ID</th><th>Patient</th><th>Doctor</th><th>Date</th><th>Time</th><th>Status</th><th></th></tr>
<?php foreach($rows as $r): ?><tr><td><?= $r['appointment_id'] ?></td><td><?= e($r['pname']) ?></td><td><?= e($r['dname']) ?> <small>(<?= e($r['specialization']) ?>)</small></td>
<td><?= e($r['appt_date']) ?></td><td><?= e(substr($r['appt_time'],0,5)) ?></td>
<td><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="status"><input type="hidden" name="id" value="<?= $r['appointment_id'] ?>">
<select name="status" onchange="this.form.submit()"><?php foreach(['Scheduled','Completed','Cancelled'] as $o) echo '<option'.($r['status']===$o?' selected':'').'>'.$o.'</option>'; ?></select></form></td>
<td><form method="post" class="inline" onsubmit="return confirm('Delete this appointment?')"><?= csrf_field() ?>
<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $r['appointment_id'] ?>"><button class="del">Delete</button></form></td></tr>
<?php endforeach; if(!$rows) echo '<tr><td colspan="7">No appointments yet</td></tr>'; ?></table></div></div>
<?php require 'footer.php'; ?>
