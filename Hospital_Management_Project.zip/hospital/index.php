<?php
require 'config.php'; need_login(); $title='Dashboard';
$c = $pdo->query("SELECT
 (SELECT COUNT(*) FROM patients) pat, (SELECT COUNT(*) FROM doctors) doc,
 (SELECT COUNT(*) FROM appointments WHERE status='Scheduled') appt,
 (SELECT IFNULL(SUM(amount),0) FROM bills WHERE payment='Paid') rev,
 (SELECT IFNULL(SUM(amount),0) FROM bills WHERE payment='Pending') pen")->fetch();
$up = $pdo->query("SELECT a.appt_date,a.appt_time,p.name pname,d.name dname,d.specialization FROM appointments a
 JOIN patients p ON p.patient_id=a.patient_id JOIN doctors d ON d.doctor_id=a.doctor_id
 WHERE a.status='Scheduled' ORDER BY a.appt_date,a.appt_time LIMIT 5")->fetchAll();
require 'header.php';
?>
<div class="stats">
<div class="card stat"><b><?= $c['pat'] ?></b><span>Patients</span></div>
<div class="card stat"><b><?= $c['doc'] ?></b><span>Doctors</span></div>
<div class="card stat"><b><?= $c['appt'] ?></b><span>Upcoming Appointments</span></div>
<div class="card stat"><b>₹<?= number_format($c['rev'],2) ?></b><span>Revenue</span></div>
<div class="card stat"><b>₹<?= number_format($c['pen'],2) ?></b><span>Pending Dues</span></div>
</div>
<div class="card"><h3>Next Appointments</h3><div class="wrap"><table>
<tr><th>Date</th><th>Time</th><th>Patient</th><th>Doctor</th><th>Department</th></tr>
<?php foreach ($up as $r): ?><tr><td><?= e($r['appt_date']) ?></td><td><?= e(substr($r['appt_time'],0,5)) ?></td>
<td><?= e($r['pname']) ?></td><td><?= e($r['dname']) ?></td><td><?= e($r['specialization']) ?></td></tr>
<?php endforeach; if (!$up) echo '<tr><td colspan="5">No upcoming appointments</td></tr>'; ?>
</table></div></div>
<?php require 'footer.php'; ?>
