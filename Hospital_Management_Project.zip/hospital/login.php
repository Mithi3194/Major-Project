<?php
require 'config.php';
$err = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  check_csrf();
  $s = $pdo->prepare('SELECT * FROM users WHERE username=?');
  $s->execute([trim($_POST['username'])]);
  $u = $s->fetch();
  if ($u && hash_equals($u['password'], hash('sha256', $_POST['password']))) {
    session_regenerate_id(true);
    $_SESSION['user']=$u['username']; $_SESSION['role']=$u['role'];
    header('Location: index.php'); exit;
  }
  $err = 'Invalid username or password';
}
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login - HMS</title><link rel="stylesheet" href="style.css"></head><body>
<div class="card login"><h2>🏥 Hospital Management</h2>
<?php if ($err): ?><div class="msg err"><?= e($err) ?></div><?php endif; ?>
<form method="post"><?= csrf_field() ?>
<label>Username</label><input name="username" required autofocus>
<label>Password</label><input name="password" type="password" required>
<button class="btn">Login</button></form></div></body></html>
