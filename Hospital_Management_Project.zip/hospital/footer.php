</main><footer>Hospital Management System &copy; BCA Final Year Project</footer></body></html>
