-- =====================================================
-- Hospital Management System - MySQL Database Script
-- Contains: schema, sample data, and useful queries
-- Run in MySQL / phpMyAdmin (XAMPP) -> Import or paste in SQL tab
-- =====================================================

DROP DATABASE IF EXISTS hospital_db;
CREATE DATABASE hospital_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hospital_db;

-- ---------- TABLES ----------

CREATE TABLE users (
  user_id     INT AUTO_INCREMENT PRIMARY KEY,
  username    VARCHAR(30)  NOT NULL UNIQUE,
  password    VARCHAR(64)  NOT NULL,          -- SHA-256 hash
  role        ENUM('Admin','Receptionist') NOT NULL DEFAULT 'Admin',
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE patients (
  patient_id  INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(60)  NOT NULL,
  age         TINYINT UNSIGNED NOT NULL CHECK (age BETWEEN 0 AND 120),
  gender      ENUM('Male','Female','Other') NOT NULL,
  phone       VARCHAR(15)  NOT NULL,
  address     VARCHAR(120),
  problem     VARCHAR(100) NOT NULL,
  reg_date    DATE NOT NULL DEFAULT (CURRENT_DATE)
);

CREATE TABLE doctors (
  doctor_id       INT AUTO_INCREMENT PRIMARY KEY,
  name            VARCHAR(60) NOT NULL,
  specialization  VARCHAR(50) NOT NULL,
  phone           VARCHAR(15) NOT NULL,
  fee             DECIMAL(8,2) NOT NULL CHECK (fee >= 0)
);

CREATE TABLE appointments (
  appointment_id  INT AUTO_INCREMENT PRIMARY KEY,
  patient_id      INT NOT NULL,
  doctor_id       INT NOT NULL,
  appt_date       DATE NOT NULL,
  appt_time       TIME NOT NULL,
  status          ENUM('Scheduled','Completed','Cancelled') NOT NULL DEFAULT 'Scheduled',
  FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE,
  FOREIGN KEY (doctor_id)  REFERENCES doctors(doctor_id)   ON DELETE CASCADE,
  UNIQUE (doctor_id, appt_date, appt_time)    -- prevents double booking
);

CREATE TABLE bills (
  bill_id     INT AUTO_INCREMENT PRIMARY KEY,
  patient_id  INT NOT NULL,
  description VARCHAR(100) NOT NULL,
  amount      DECIMAL(10,2) NOT NULL CHECK (amount >= 0),
  payment     ENUM('Paid','Pending') NOT NULL DEFAULT 'Pending',
  bill_date   DATE NOT NULL DEFAULT (CURRENT_DATE),
  FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
);

-- ---------- SAMPLE DATA ----------

INSERT INTO users (username, password, role) VALUES
('admin',  SHA2('admin123',256), 'Admin'),
('desk1',  SHA2('desk123',256),  'Receptionist');

INSERT INTO patients (name, age, gender, phone, address, problem, reg_date) VALUES
('Rahul Sharma',   34, 'Male',   '9876543210', 'Andheri, Mumbai',   'Fever',            '2026-09-20'),
('Priya Patil',    28, 'Female', '9822011223', 'Thane',             'Migraine',         '2026-09-21'),
('Amit Verma',     45, 'Male',   '9811200345', 'Borivali, Mumbai',  'Chest pain',       '2026-09-22'),
('Sneha Kulkarni', 52, 'Female', '9833377889', 'Pune',              'Diabetes checkup', '2026-09-23'),
('Mohammed Iqbal', 61, 'Male',   '9867054321', 'Bandra, Mumbai',    'Knee pain',        '2026-09-24'),
('Anjali Nair',    7,  'Female', '9820098765', 'Navi Mumbai',       'Cough and cold',   '2026-09-25'),
('Vikram Singh',   39, 'Male',   '9892012345', 'Dadar, Mumbai',     'Back pain',        '2026-09-26'),
('Kavita Desai',   31, 'Female', '9004455667', 'Kandivali, Mumbai', 'Skin allergy',     '2026-09-27'),
('Suresh Joshi',   68, 'Male',   '9930011223', 'Nashik',            'High blood pressure','2026-09-28'),
('Neha Gupta',     24, 'Female', '9769988776', 'Malad, Mumbai',     'Stomach ache',     '2026-09-29');

INSERT INTO doctors (name, specialization, phone, fee) VALUES
('Dr. A. Mehta',   'General Physician', '9811122233', 500.00),
('Dr. S. Rao',     'Neurologist',       '9899988877', 900.00),
('Dr. R. Kapoor',  'Cardiologist',      '9822233344', 1000.00),
('Dr. P. Iyer',    'Diabetologist',     '9833344455', 700.00),
('Dr. N. Shah',    'Orthopedic',        '9844455566', 800.00),
('Dr. M. D''Souza','Dermatologist',     '9855566677', 600.00);

INSERT INTO appointments (patient_id, doctor_id, appt_date, appt_time, status) VALUES
(1, 1, '2026-09-20', '10:00:00', 'Completed'),
(2, 2, '2026-09-21', '11:30:00', 'Completed'),
(3, 3, '2026-09-22', '09:30:00', 'Completed'),
(4, 4, '2026-09-23', '12:00:00', 'Completed'),
(5, 5, '2026-09-24', '16:00:00', 'Cancelled'),
(6, 1, '2026-10-05', '10:30:00', 'Scheduled'),
(7, 5, '2026-10-05', '11:00:00', 'Scheduled'),
(8, 6, '2026-10-06', '15:00:00', 'Scheduled'),
(9, 3, '2026-10-07', '09:00:00', 'Scheduled'),
(10,1, '2026-10-07', '10:00:00', 'Scheduled');

INSERT INTO bills (patient_id, description, amount, payment, bill_date) VALUES
(1, 'Consultation',               500.00,  'Paid',    '2026-09-20'),
(2, 'Consultation + MRI Brain',   5900.00, 'Paid',    '2026-09-21'),
(3, 'Consultation + ECG',         1400.00, 'Paid',    '2026-09-22'),
(4, 'Consultation + Blood tests', 1850.00, 'Pending', '2026-09-23'),
(5, 'Consultation (cancelled)',   0.00,    'Paid',    '2026-09-24'),
(7, 'Advance booking fee',        200.00,  'Paid',    '2026-10-01'),
(9, 'Advance booking fee',        200.00,  'Pending', '2026-10-01');

-- ---------- USEFUL QUERIES (Dashboard / Reports) ----------

-- 1. Dashboard counts
SELECT (SELECT COUNT(*) FROM patients) AS total_patients,
       (SELECT COUNT(*) FROM doctors)  AS total_doctors,
       (SELECT COUNT(*) FROM appointments WHERE status='Scheduled') AS upcoming_appointments,
       (SELECT IFNULL(SUM(amount),0) FROM bills WHERE payment='Paid')    AS revenue,
       (SELECT IFNULL(SUM(amount),0) FROM bills WHERE payment='Pending') AS pending_dues;

-- 2. Appointment list with names
SELECT a.appointment_id, p.name AS patient, d.name AS doctor,
       d.specialization, a.appt_date, a.appt_time, a.status
FROM appointments a
JOIN patients p ON p.patient_id = a.patient_id
JOIN doctors  d ON d.doctor_id  = a.doctor_id
ORDER BY a.appt_date, a.appt_time;

-- 3. Bill report per patient
SELECT p.name, SUM(b.amount) AS total_billed,
       SUM(CASE WHEN b.payment='Pending' THEN b.amount ELSE 0 END) AS pending
FROM bills b JOIN patients p ON p.patient_id = b.patient_id
GROUP BY p.patient_id, p.name;

-- 4. Search patient by name
SELECT * FROM patients WHERE name LIKE '%Sharma%';

-- 5. Doctor-wise appointment count
SELECT d.name, COUNT(a.appointment_id) AS appointments
FROM doctors d LEFT JOIN appointments a ON a.doctor_id = d.doctor_id
GROUP BY d.doctor_id, d.name;
