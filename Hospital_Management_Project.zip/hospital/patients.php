<?php
require 'config.php'; need_login(); check_csrf();
if ($_SERVER['REQUEST_METHOD']==='POST') {
  if (($_POST['action']??'')==='delete') {
    $pdo->prepare('DELETE FROM patients WHERE patient_id=?')->execute([(int)$_POST['id']]);
    flash('Patient deleted.');
  } else {
    $id=(int)($_POST['id']??0); $name=trim($_POST['name']); $age=(int)$_POST['age']; $g=$_POST['gender'];
    $ph=trim($_POST['phone']); $ad=trim($_POST['address']); $pr=trim($_POST['problem']);
    if ($name===''||$pr===''||$age<0||$age>120||!in_array($g,['Male','Female','Other'])||!preg_match('/^[0-9]{10}$/',$ph)) {
      flash('Error: please enter valid details (phone must be 10 digits).');
    } elseif ($id) {
      $pdo->prepare('UPDATE patients SET name=?,age=?,gender=?,phone=?,address=?,problem=? WHERE patient_id=?')->execute([$name,$age,$g,$ph,$ad,$pr,$id]);
      flash('Patient updated.');
    } else {
      $pdo->prepare('INSERT INTO patients(name,age,gender,phone,address,problem) VALUES(?,?,?,?,?,?)')->execute([$name,$age,$g,$ph,$ad,$pr]);
      flash('Patient added.');
    }
  }
  header('Location: patients.php'); exit;
}
$title='Patients'; $edit=null;
if (isset($_GET['edit'])) { $s=$pdo->prepare('SELECT * FROM patients WHERE patient_id=?'); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch()?:null; }
$q=trim($_GET['q']??''); $l="%$q%";
$s=$pdo->prepare('SELECT * FROM patients WHERE name LIKE ? OR phone LIKE ? OR problem LIKE ? ORDER BY patient_id DESC'); $s->execute([$l,$l,$l]); $rows=$s->fetchAll();
require 'header.php';
?>
<div class="card"><h3><?= $edit?'Edit':'Add' ?> Patient</h3>
<form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $edit['patient_id']??0 ?>">
<div><label>Name</label><input name="name" required value="<?= e($edit['name']??'') ?>"></div>
<div><label>Age</label><input name="age" type="number" min="0" max="120" required value="<?= e($edit['age']??'') ?>"></div>
<div><label>Gender</label><select name="gender"><?php foreach(['Male','Female','Other'] as $o) echo '<option'.(($edit['gender']??'')===$o?' selected':'').'>'.$o.'</option>'; ?></select></div>
<div><label>Phone (10 digits)</label><input name="phone" required pattern="[0-9]{10}" value="<?= e($edit['phone']??'') ?>"></div>
<div><label>Address</label><input name="address" value="<?= e($edit['address']??'') ?>"></div>
<div><label>Problem</label><input name="problem" required value="<?= e($edit['problem']??'') ?>"></div>
<button class="btn"><?= $edit?'Update':'Add' ?></button><?php if($edit) echo ' <a href="patients.php">Cancel</a>'; ?></form></div>
<div class="card"><div class="bar"><h3>Patients (<?= count($rows) ?>)</h3>
<form method="get" class="inline"><input name="q" placeholder="Search name / phone / problem" value="<?= e($q) ?>"><button class="btn">Search</button></form></div>
<div class="wrap"><table><tr><th>ID</th><th>Name</th><th>Age</th><th>Gender</th><th>Phone</th><th>Address</th><th>Problem</th><th>Registered</th><th></th></tr>
<?php foreach($rows as $r): ?><tr><td><?= $r['patient_id'] ?></td><td><?= e($r['name']) ?></td><td><?= $r['age'] ?></td><td><?= e($r['gender']) ?></td>
<td><?= e($r['phone']) ?></td><td><?= e($r['address']) ?></td><td><?= e($r['problem']) ?></td><td><?= e($r['reg_date']) ?></td>
<td><a href="?edit=<?= $r['patient_id'] ?>">Edit</a>
<form method="post" class="inline" onsubmit="return confirm('Delete this patient and related records?')"><?= csrf_field() ?>
<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $r['patient_id'] ?>"><button class="del">Delete</button></form></td></tr>
<?php endforeach; if(!$rows) echo '<tr><td colspan="9">No records found</td></tr>'; ?></table></div></div>
<?php require 'footer.php'; ?>
