<?php
require 'config.php'; need_login(); check_csrf();
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $a=$_POST['action']??'add';
  if ($a==='delete') { $pdo->prepare('DELETE FROM bills WHERE bill_id=?')->execute([(int)$_POST['id']]); flash('Bill deleted.'); }
  elseif ($a==='payment' && in_array($_POST['payment'],['Paid','Pending'])) {
    $pdo->prepare('UPDATE bills SET payment=? WHERE bill_id=?')->execute([$_POST['payment'],(int)$_POST['id']]); flash('Payment status updated.');
  } elseif ($a==='add') {
    $desc=trim($_POST['description']); $amt=(float)$_POST['amount'];
    if ($desc===''||$amt<0) flash('Error: enter a valid description and amount.');
    else { $pdo->prepare('INSERT INTO bills(patient_id,description,amount,payment) VALUES(?,?,?,?)')
      ->execute([(int)$_POST['patient_id'],$desc,$amt,$_POST['payment']==='Paid'?'Paid':'Pending']); flash('Bill generated.'); }
  }
  header('Location: billing.php'); exit;
}
$title='Billing';
$pats=$pdo->query('SELECT patient_id,name FROM patients ORDER BY name')->fetchAll();
$rows=$pdo->query('SELECT b.*,p.name pname FROM bills b JOIN patients p ON p.patient_id=b.patient_id ORDER BY b.bill_id DESC')->fetchAll();
require 'header.php';
?>
<div class="card"><h3>Generate Bill</h3>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="add">
<div><label>Patient</label><select name="patient_id" required><?php foreach($pats as $p) echo '<option value="'.$p['patient_id'].'">'.e($p['name']).'</option>'; ?></select></div>
<div><label>Description</label><input name="description" required></div>
<div><label>Amount (₹)</label><input name="amount" type="number" step="0.01" min="0" required></div>
<div><label>Payment</label><select name="payment"><option>Pending</option><option>Paid</option></select></div>
<button class="btn">Generate</button></form></div>
<div class="card"><h3>Bills (<?= count($rows) ?>)</h3><div class="wrap"><table>
<tr><th>Bill No.</th><th>Patient</th><th>Description</th><th>Amount</th><th>Date</th><th>Payment</th><th></th></tr>
<?php foreach($rows as $r): ?><tr><td><?= $r['bill_id'] ?></td><td><?= e($r['pname']) ?></td><td><?= e($r['description']) ?></td>
<td>₹<?= number_format($r['amount'],2) ?></td><td><?= e($r['bill_date']) ?></td>
<td><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="payment"><input type="hidden" name="id" value="<?= $r['bill_id'] ?>">
<select name="payment" onchange="this.form.submit()"><?php foreach(['Paid','Pending'] as $o) echo '<option'.($r['payment']===$o?' selected':'').'>'.$o.'</option>'; ?></select></form></td>
<td><a href="invoice.php?id=<?= $r['bill_id'] ?>" target="_blank">Print</a>
<form method="post" class="inline" onsubmit="return confirm('Delete this bill?')"><?= csrf_field() ?>
<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $r['bill_id'] ?>"><button class="del">Delete</button></form></td></tr>
<?php endforeach; if(!$rows) echo '<tr><td colspan="7">No bills yet</td></tr>'; ?></table></div></div>
<?php require 'footer.php'; ?>
