<?php
require 'config.php'; need_login(); check_csrf();
if ($_SERVER['REQUEST_METHOD']==='POST') {
  if (($_POST['action']??'')==='delete') {
    $pdo->prepare('DELETE FROM doctors WHERE doctor_id=?')->execute([(int)$_POST['id']]); flash('Doctor deleted.');
  } else {
    $id=(int)($_POST['id']??0); $name=trim($_POST['name']); $sp=trim($_POST['spec']); $ph=trim($_POST['phone']); $fee=(float)$_POST['fee'];
    if ($name===''||$sp===''||$fee<0||!preg_match('/^[0-9]{10}$/',$ph)) flash('Error: please enter valid details (phone must be 10 digits).');
    elseif ($id) { $pdo->prepare('UPDATE doctors SET name=?,specialization=?,phone=?,fee=? WHERE doctor_id=?')->execute([$name,$sp,$ph,$fee,$id]); flash('Doctor updated.'); }
    else { $pdo->prepare('INSERT INTO doctors(name,specialization,phone,fee) VALUES(?,?,?,?)')->execute([$name,$sp,$ph,$fee]); flash('Doctor added.'); }
  }
  header('Location: doctors.php'); exit;
}
$title='Doctors'; $edit=null;
if (isset($_GET['edit'])) { $s=$pdo->prepare('SELECT * FROM doctors WHERE doctor_id=?'); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch()?:null; }
$q=trim($_GET['q']??''); $l="%$q%";
$s=$pdo->prepare('SELECT * FROM doctors WHERE name LIKE ? OR specialization LIKE ? ORDER BY doctor_id DESC'); $s->execute([$l,$l]); $rows=$s->fetchAll();
require 'header.php';
?>
<div class="card"><h3><?= $edit?'Edit':'Add' ?> Doctor</h3>
<form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $edit['doctor_id']??0 ?>">
<div><label>Name</label><input name="name" required value="<?= e($edit['name']??'') ?>"></div>
<div><label>Specialization</label><input name="spec" required value="<?= e($edit['specialization']??'') ?>"></div>
<div><label>Phone (10 digits)</label><input name="phone" required pattern="[0-9]{10}" value="<?= e($edit['phone']??'') ?>"></div>
<div><label>Fee (₹)</label><input name="fee" type="number" step="0.01" min="0" required value="<?= e($edit['fee']??'') ?>"></div>
<button class="btn"><?= $edit?'Update':'Add' ?></button><?php if($edit) echo ' <a href="doctors.php">Cancel</a>'; ?></form></div>
<div class="card"><div class="bar"><h3>Doctors (<?= count($rows) ?>)</h3>
<form method="get" class="inline"><input name="q" placeholder="Search name / specialization" value="<?= e($q) ?>"><button class="btn">Search</button></form></div>
<div class="wrap"><table><tr><th>ID</th><th>Name</th><th>Specialization</th><th>Phone</th><th>Fee</th><th></th></tr>
<?php foreach($rows as $r): ?><tr><td><?= $r['doctor_id'] ?></td><td><?= e($r['name']) ?></td><td><?= e($r['specialization']) ?></td><td><?= e($r['phone']) ?></td><td>₹<?= number_format($r['fee'],2) ?></td>
<td><a href="?edit=<?= $r['doctor_id'] ?>">Edit</a>
<form method="post" class="inline" onsubmit="return confirm('Delete this doctor and related appointments?')"><?= csrf_field() ?>
<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $r['doctor_id'] ?>"><button class="del">Delete</button></form></td></tr>
<?php endforeach; if(!$rows) echo '<tr><td colspan="6">No records found</td></tr>'; ?></table></div></div>
<?php require 'footer.php'; ?>
