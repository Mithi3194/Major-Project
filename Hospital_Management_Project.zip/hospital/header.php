<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? 'HMS') ?> - Hospital Management System</title>
<link rel="stylesheet" href="style.css"></head><body>
<header><h1>🏥 Hospital Management System</h1>
<span><?= e($_SESSION['user'] ?? '') ?> (<?= e($_SESSION['role'] ?? '') ?>) &nbsp;<a href="logout.php">Logout</a></span></header>
<nav><?php foreach (['index.php'=>'Dashboard','patients.php'=>'Patients','doctors.php'=>'Doctors','appointments.php'=>'Appointments','billing.php'=>'Billing'] as $f=>$n)
 echo '<a href="'.$f.'" class="'.(basename($_SERVER['PHP_SELF'])===$f?'on':'').'">'.$n.'</a>'; ?></nav>
<main>
<?php if ($m = flash()): ?><div class="msg"><?= e($m) ?></div><?php endif; ?>
